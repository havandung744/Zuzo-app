package com.example.baitapcuoiki.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.PagerAdapter;

import com.example.baitapcuoiki.R;

public class SliderAdapter extends PagerAdapter{ // tạo thanh trượt theo chiều ngang

    Context context; // cho phép truy cập tới các thành phần của ứng dụng
    LayoutInflater layoutInflater; // tạo một view từ file xml

    public SliderAdapter(Context context){
        this.context = context;
    }

    int imagesArray[] = { // lấy ra ảnh trong thư mục drawable
            R.drawable.onboardscreen1,
            R.drawable.onboardscreen2,
            R.drawable.onboardscreen3,
    };

    int headingArray[] = { //lấy tên
            R.string.first_slide,
            R.string.second_slide,
            R.string.third_slide
    };

    int descriptionArray[] = { // mô tả
            R.string.description,
            R.string.description1,
            R.string.description2
    };


    @Override
    public int getCount() {
        return headingArray.length;
    } // đếm số phần tử của headingArray

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == (ConstraintLayout) object;
    }

    @NonNull
    @Override
    // hàm build view lên ứng dụng
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.sliding_layout, container, false);

        ImageView imageView = view.findViewById(R.id.slider_img);
        TextView heading = view.findViewById(R.id.heading);
        TextView description  = view.findViewById(R.id.description);

        imageView.setImageResource(imagesArray[position]);
        heading.setText(headingArray[position]);
        description.setText(descriptionArray[position]);

        container.addView(view);


        return view;
    }

    @Override
    // ngắt kết nối đến view
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((ConstraintLayout)object);
    }
}

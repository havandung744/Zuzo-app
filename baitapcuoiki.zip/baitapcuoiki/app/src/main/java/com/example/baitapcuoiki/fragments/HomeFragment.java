package com.example.baitapcuoiki.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.baitapcuoiki.R;
import com.example.baitapcuoiki.activities.ShowAllActivity;
import com.example.baitapcuoiki.adapters.CategoryAdapter;
import com.example.baitapcuoiki.adapters.NewProductsAdapter;
import com.example.baitapcuoiki.adapters.PopularProductsAdapter;
import com.example.baitapcuoiki.models.CategoryModel;
import com.example.baitapcuoiki.models.NewProductsModel;
import com.example.baitapcuoiki.models.PopularProductsModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

// Fragment như là một sub-activity
//trong các ứng dụng android, tại một thời điểm, chỉ có một Activity được hiển thị duy nhất trên màn hình.
// Chúng ta muốn chia màn hình ra nhiều phần để dễ sử dụng thì fragment đáp ứng điều đó
public class HomeFragment extends Fragment {

    // show all
    TextView catShowAll, popularShowAll, newProductsShowAll;


    LinearLayout linearLayout;
    ProgressDialog progressDialog;
    RecyclerView catRecyclerview,newProductRecyclerview,popularRecyclerview;

    // category recyclerview
    CategoryAdapter categoryAdapter;
    List<CategoryModel> categoryModelList;

    // new product recyclerview
    NewProductsAdapter newProductsAdapter;
    List<NewProductsModel> newProductsModelsList;

    //popular product
    PopularProductsAdapter popularProductsAdapter;
    List<PopularProductsModel> popularProductsModelList;




    //FireStore
    FirebaseFirestore db;


    public HomeFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // LayoutInflater là 1 component giúp bạn chuyển layout file(Xml) thành View(Java code)
        // tạo chết độ xem từ tệp xml của mình
//       attachToRoot=true thì ngay sau khi quá trình chuyển
//        đổi xml file thành View hoàn thành thì nó sẽ nhúng View đó vào ViewGroup parent
//        attachToRoot = false thì nó chỉ chuyển đổi xml file
//        thành View trong java mà không thêm ngay vào ViewGroup
        View root =  inflater.inflate(R.layout.fragment_home, container, false);

        db = FirebaseFirestore.getInstance();

        progressDialog = new ProgressDialog(getActivity()); // khởi tạo progressDialog
        catRecyclerview = root.findViewById(R.id.rec_category);
        newProductRecyclerview = root.findViewById(R.id.new_product_rec);
        popularRecyclerview = root.findViewById(R.id.popular_rec);
//        categoryModelList = root.findViewById(R.id.rec_category);

        // show all
        catShowAll = root.findViewById(R.id.category_see_all);
        popularShowAll = root.findViewById(R.id.popular_see_all);
        newProductsShowAll = root.findViewById(R.id.newProducts_see_all);

        catShowAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), ShowAllActivity.class);
                startActivity(intent);
            }
        });

        newProductsShowAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), ShowAllActivity.class);
                startActivity(intent);
            }
        });

        popularShowAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), ShowAllActivity.class);
                startActivity(intent);
            }
        });

                // linerlayout
        linearLayout = root.findViewById(R.id.home_layout);
        linearLayout.setVisibility(View.GONE);

        // image slider
        ImageSlider imageSlider = root.findViewById(R.id.image_slider);
        List<SlideModel> slideModels = new ArrayList<>();

        slideModels.add(new SlideModel(R.drawable.banner1,"Giảm giá giày", ScaleTypes.CENTER_CROP));
        slideModels.add(new SlideModel(R.drawable.banner2,"Giảm giá nước hoa", ScaleTypes.CENTER_CROP));
        slideModels.add(new SlideModel(R.drawable.banner3,"Giảm giá 50%", ScaleTypes.CENTER_CROP));


        imageSlider.setImageList(slideModels);

        progressDialog.setTitle("Chào mừng bạn đến ZuZo App");
        progressDialog.setMessage("Vui lòng chờ...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();



//        //Sản phẩm
        catRecyclerview.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.HORIZONTAL,false));
        categoryModelList = new ArrayList<>();
        categoryAdapter = new CategoryAdapter(getContext(), categoryModelList);
        catRecyclerview.setAdapter(categoryAdapter);

//        //lấy dữ liệu
        db.collection("Category")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                CategoryModel categoryModel = document.toObject(CategoryModel.class);
                                categoryModelList.add(categoryModel);
                                categoryAdapter.notifyDataSetChanged();
//                                Log.w("err",categoryModel.toString());
                                linearLayout.setVisibility(getView().VISIBLE);
                                progressDialog.dismiss();
                            }
                        } else {
                            Toast.makeText(getActivity(), (CharSequence) task.getException(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });



        // sản phẩm mới

        newProductRecyclerview.setLayoutManager(new LinearLayoutManager(getActivity(),RecyclerView.HORIZONTAL,false));
        newProductsModelsList = new ArrayList<>();
        newProductsAdapter = new NewProductsAdapter(getContext(), newProductsModelsList);
        newProductRecyclerview.setAdapter(newProductsAdapter);

        //  lấy dữ liệu
        db.collection("NewProducts")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                NewProductsModel newProductsModel = document.toObject(NewProductsModel.class);
                                newProductsModelsList.add(newProductsModel);
                                newProductsAdapter.notifyDataSetChanged();
                                Log.w("err", newProductsModel.toString());

                            }
                        } else {
                            Toast.makeText(getActivity(), (CharSequence) task.getException(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });




        // sản phẩm nổi bật
        // đổi linerlayoutmanager thành griblayoutmanager để hiển thị kiểu khác
        popularRecyclerview.setLayoutManager(new GridLayoutManager(getActivity(),2));
        popularProductsModelList = new ArrayList<>();
        popularProductsAdapter = new PopularProductsAdapter(getContext(), popularProductsModelList);
        popularRecyclerview.setAdapter(popularProductsAdapter);

        //        //read data
        db.collection("AllProducts")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                PopularProductsModel popularProductsModel = document.toObject(PopularProductsModel.class);
                                popularProductsModelList.add(popularProductsModel);
                                popularProductsAdapter.notifyDataSetChanged();
                                Log.w("err", popularProductsModel.toString());

                            }
                        } else {
                            Toast.makeText(getActivity(), (CharSequence) task.getException(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });





        return root;
    }
}
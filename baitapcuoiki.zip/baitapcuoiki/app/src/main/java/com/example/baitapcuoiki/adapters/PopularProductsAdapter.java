package com.example.baitapcuoiki.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.baitapcuoiki.R;
import com.example.baitapcuoiki.activities.DetailedActivity;
import com.example.baitapcuoiki.models.PopularProductsModel;

import java.util.List;

public class PopularProductsAdapter extends RecyclerView.Adapter<PopularProductsAdapter.Viewholder> {

    private Context context;
    private List<PopularProductsModel> popularProductsModellist;

    public PopularProductsAdapter(Context context, List<PopularProductsModel> popularProductsModellist) {
        this.context = context;
        this.popularProductsModellist = popularProductsModellist;
    }

    @NonNull
    @Override
    public PopularProductsAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Viewholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.popular_items,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull PopularProductsAdapter.Viewholder holder, int position) {

        Glide.with(context).load(popularProductsModellist.get(position).getImg_url()).into(holder.imageView);
        holder.name.setText(popularProductsModellist.get(position).getName());
        holder.price.setText(String.valueOf(popularProductsModellist.get(position).getPrice()));

        // xu li khi click vao san pham hien thong tin chi tiet cua san pham
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailedActivity.class);
                intent.putExtra("detailed", popularProductsModellist.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return popularProductsModellist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView name, price;

        public Viewholder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.all_img);
            name = itemView.findViewById(R.id.all_product_name);
            price = itemView.findViewById(R.id.all_price);
        }
    }
}

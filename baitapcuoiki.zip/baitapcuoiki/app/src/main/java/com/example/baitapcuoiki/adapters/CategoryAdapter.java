package com.example.baitapcuoiki.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.baitapcuoiki.R;
import com.example.baitapcuoiki.activities.ShowAllActivity;
import com.example.baitapcuoiki.models.CategoryModel;

import java.util.List;

//RecyclerView là phiên bản ListView nâng cao và linh hoạt hơn
public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    private Context context; // cho phép truy cập thông tin của ứng dụng
    private List<CategoryModel> list;

    // hàm khởi tạo không tham số
    public CategoryAdapter() {
    }
    // hàm khởi tạo có tham số
    public CategoryAdapter(Context context, List<CategoryModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.catagory_list,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

//        Glide là open source hỗ trợ load ảnh trên android
        Glide.with(context).load(list.get(position).getImg_url()).into(holder.catImg);
//        Log.w("img url",list.get(position).getImg_url());
         holder.catName.setText(list.get(position).getName());

         holder.itemView.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent intent = new Intent(context, ShowAllActivity.class);
                 intent.putExtra("type", list.get(position).getType());
                 context.startActivity(intent);
             }
         });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView catImg;
        TextView catName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            catImg = itemView.findViewById(R.id.cat_img);
            catName = itemView.findViewById(R.id.cat_name);

        }
    }
}
